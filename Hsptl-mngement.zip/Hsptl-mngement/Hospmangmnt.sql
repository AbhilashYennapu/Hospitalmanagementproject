create database Hospmangmnt;
use Hospmangmnt;
create table patient(name varchar(50),age int, gender varchar(10),email varchar(50),issue varchar(20),sissue varchar(100),pid varchar(10),adress varchar(50),pass varchar(10),adate date);

create table doctor(name varchar(50), age int, gender varchar(10), email varchar(40), 
 specin varchar(50),specifics varchar(100),adress varchar(50),did varchar(10), pass varchar(10));
